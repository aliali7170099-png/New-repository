package com.arabickeyboard.pro;

import android.inputmethodservice.InputMethodService;
import android.os.SystemClock;
import android.text.InputType;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.view.inputmethod.InputMethodManager;
import android.widget.LinearLayout;

import java.util.Collections;
import java.util.List;

public class KeyboardService extends InputMethodService
        implements KeyboardView.Listener, SuggestionBar.Listener {

    private Prefs prefs;
    private SuggestionEngine engine;
    private LinearLayout root;
    private SuggestionBar bar;
    private KeyboardView kv;

    private int mode = Layouts.MODE_LETTERS;
    private boolean arabic = true;
    private int shift = 0;            // 0 off, 1 once, 2 caps lock / tashkeel layer
    private int emojiCat = 0;
    private long lastShiftTap;
    private long lastSpace;
    private boolean suggestionsAllowed = true;
    private boolean capEnabled = false;
    private String currentPrefix = "";

    @Override
    public void onCreate() {
        super.onCreate();
        prefs = new Prefs(this);
        engine = new SuggestionEngine(this);
        arabic = prefs.lastArabic();
    }

    @Override
    public boolean onEvaluateFullscreenMode() {
        return false;
    }

    @Override
    public View onCreateInputView() {
        float d = getResources().getDisplayMetrics().density;
        bar = new SuggestionBar(this);
        bar.setListener(this);
        kv = new KeyboardView(this);
        kv.setListener(this);
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.addView(bar, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, Math.round(44 * d)));
        root.addView(kv, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        applyPrefs();
        updateKeyboard();
        return root;
    }

    private void applyPrefs() {
        if (root == null) return;
        Theme t = Theme.get(prefs.theme());
        root.setBackgroundColor(t.bg);
        bar.setTheme(t);
        kv.setTheme(t);
        kv.setOptions(prefs.vibrate(), prefs.sound(), prefs.preview(), prefs.keyHeight());
        bar.setVisibility(prefs.suggest() ? View.VISIBLE : View.GONE);
    }

    @Override
    public void onStartInputView(EditorInfo info, boolean restarting) {
        super.onStartInputView(info, restarting);
        if (root == null) return;
        prefs = new Prefs(this);
        engine.reloadLearned();
        applyPrefs();

        int cls = info.inputType & InputType.TYPE_MASK_CLASS;
        int var = info.inputType & InputType.TYPE_MASK_VARIATION;
        boolean text = cls == InputType.TYPE_CLASS_TEXT;
        boolean pass = (text && (var == InputType.TYPE_TEXT_VARIATION_PASSWORD
                || var == InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
                || var == InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD))
                || (cls == InputType.TYPE_CLASS_NUMBER && var == InputType.TYPE_NUMBER_VARIATION_PASSWORD);
        boolean emailUrl = text && (var == InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS
                || var == InputType.TYPE_TEXT_VARIATION_WEB_EMAIL_ADDRESS
                || var == InputType.TYPE_TEXT_VARIATION_URI);

        suggestionsAllowed = prefs.suggest() && text && !pass && !emailUrl
                && (info.inputType & InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS) == 0;
        capEnabled = text && !pass && !emailUrl;

        if (!restarting) {
            mode = (cls == InputType.TYPE_CLASS_NUMBER || cls == InputType.TYPE_CLASS_PHONE
                    || cls == InputType.TYPE_CLASS_DATETIME)
                    ? Layouts.MODE_SYM1 : Layouts.MODE_LETTERS;
            arabic = (pass || emailUrl) ? false : prefs.lastArabic();
            shift = 0;
        }
        kv.setEnterLabel(enterLabelFor(info));
        updateKeyboard();
        updateAutoShift();
        updateSuggestions();
    }

    @Override
    public void onFinishInputView(boolean finishingInput) {
        super.onFinishInputView(finishingInput);
        if (kv != null) kv.reset();
    }

    @Override
    public void onUpdateSelection(int oldSelStart, int oldSelEnd, int newSelStart, int newSelEnd,
                                  int candStart, int candEnd) {
        super.onUpdateSelection(oldSelStart, oldSelEnd, newSelStart, newSelEnd, candStart, candEnd);
        updateSuggestions();
    }

    private String enterLabelFor(EditorInfo ei) {
        if ((ei.imeOptions & EditorInfo.IME_FLAG_NO_ENTER_ACTION) != 0) return null;
        if (ei.actionLabel != null && ei.actionLabel.length() > 0) return ei.actionLabel.toString();
        switch (ei.imeOptions & EditorInfo.IME_MASK_ACTION) {
            case EditorInfo.IME_ACTION_GO: return "اذهب";
            case EditorInfo.IME_ACTION_SEARCH: return "بحث";
            case EditorInfo.IME_ACTION_SEND: return "إرسال";
            case EditorInfo.IME_ACTION_NEXT: return "التالي";
            case EditorInfo.IME_ACTION_PREVIOUS: return "السابق";
            case EditorInfo.IME_ACTION_DONE: return "تم";
            default: return null;
        }
    }

    private void updateKeyboard() {
        if (kv == null) return;
        kv.setLayout(Layouts.build(mode, arabic, shift, prefs.numberRow(),
                        prefs.arabicDigits(), emojiCat),
                arabic, shift, emojiCat, arabic ? "العربية" : "English");
    }

    // ---------------- key handling ----------------

    @Override
    public void onKey(Key k) {
        switch (k.code) {
            case Key.SHIFT:
                if (arabic) {
                    shift = (shift == 0) ? 2 : 0;
                } else {
                    long now = SystemClock.uptimeMillis();
                    if (now - lastShiftTap < 350) shift = 2;
                    else shift = (shift == 0) ? 1 : 0;
                    lastShiftTap = now;
                }
                updateKeyboard();
                break;
            case Key.SYM1:
                mode = Layouts.MODE_SYM1;
                updateKeyboard();
                break;
            case Key.SYM2:
                mode = (mode == Layouts.MODE_SYM1) ? Layouts.MODE_SYM2 : Layouts.MODE_SYM1;
                updateKeyboard();
                break;
            case Key.LETTERS:
                mode = Layouts.MODE_LETTERS;
                updateKeyboard();
                updateAutoShift();
                break;
            case Key.EMOJI:
                mode = Layouts.MODE_EMOJI;
                updateKeyboard();
                break;
            case Key.CAT:
                emojiCat = k.arg;
                updateKeyboard();
                break;
            case Key.LANG:
                arabic = !arabic;
                shift = 0;
                mode = Layouts.MODE_LETTERS;
                prefs.setLastArabic(arabic);
                updateKeyboard();
                updateAutoShift();
                break;
            case Key.DELETE:
                sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL);
                updateAutoShift();
                updateSuggestions();
                break;
            case Key.ENTER:
                handleEnter();
                break;
            case Key.SPACE:
                handleSpace();
                break;
            default:
                if (k.output != null && !k.output.isEmpty()) typeText(k.output);
        }
    }

    @Override
    public void onText(String text) {
        typeText(text);
    }

    @Override
    public void onLongPressKey(Key k) {
        if (k.code == Key.LANG) {
            InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
            if (imm != null) imm.showInputMethodPicker();
        }
    }

    private void typeText(String s) {
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) return;
        ic.commitText(s, 1);
        if (!arabic && shift == 1 && mode == Layouts.MODE_LETTERS) {
            shift = 0;
            updateKeyboard();
        }
        updateAutoShift();
        updateSuggestions();
    }

    private void handleEnter() {
        InputConnection ic = getCurrentInputConnection();
        EditorInfo ei = getCurrentInputEditorInfo();
        if (ic == null) return;
        int action = ei == null ? EditorInfo.IME_ACTION_NONE : (ei.imeOptions & EditorInfo.IME_MASK_ACTION);
        boolean noAction = ei == null
                || (ei.imeOptions & EditorInfo.IME_FLAG_NO_ENTER_ACTION) != 0
                || action == EditorInfo.IME_ACTION_NONE
                || action == EditorInfo.IME_ACTION_UNSPECIFIED;
        if (noAction) sendDownUpKeyEvents(KeyEvent.KEYCODE_ENTER);
        else ic.performEditorAction(action);
        updateAutoShift();
        updateSuggestions();
    }

    private void handleSpace() {
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) return;
        long now = SystemClock.uptimeMillis();
        if (suggestionsAllowed) {
            String w = lastWord(ic.getTextBeforeCursor(30, 0));
            if (w.length() >= 2) engine.learn(w);
        }
        if (prefs.doubleSpace() && now - lastSpace < 350) {
            CharSequence b = ic.getTextBeforeCursor(2, 0);
            if (b != null && b.length() == 2 && b.charAt(1) == ' '
                    && Character.isLetterOrDigit(b.charAt(0))) {
                ic.beginBatchEdit();
                ic.deleteSurroundingText(1, 0);
                ic.commitText(". ", 1);
                ic.endBatchEdit();
                lastSpace = 0;
                updateAutoShift();
                updateSuggestions();
                return;
            }
        }
        ic.commitText(" ", 1);
        lastSpace = now;
        updateAutoShift();
        updateSuggestions();
    }

    // ---------------- auto-capitalisation & suggestions ----------------

    private void updateAutoShift() {
        if (arabic || mode != Layouts.MODE_LETTERS || shift == 2 || !capEnabled) return;
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) return;
        int caps = ic.getCursorCapsMode(InputType.TYPE_CLASS_TEXT
                | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        int ns = caps != 0 ? 1 : 0;
        if (ns != shift) {
            shift = ns;
            updateKeyboard();
        }
    }

    private static String lastWord(CharSequence before) {
        if (before == null) return "";
        int end = before.length();
        int i = end;
        while (i > 0) {
            char c = before.charAt(i - 1);
            if (Character.isLetter(c) || Character.getType(c) == Character.NON_SPACING_MARK) i--;
            else break;
        }
        return before.subSequence(i, end).toString();
    }

    private void updateSuggestions() {
        if (bar == null) return;
        InputConnection ic = getCurrentInputConnection();
        if (!suggestionsAllowed || ic == null) {
            currentPrefix = "";
            bar.setSuggestions(Collections.<String>emptyList());
            return;
        }
        currentPrefix = lastWord(ic.getTextBeforeCursor(30, 0));
        List<String> list = currentPrefix.isEmpty()
                ? Collections.<String>emptyList()
                : engine.suggest(currentPrefix, 3);
        bar.setSuggestions(list);
    }

    @Override
    public void onSuggestion(String word) {
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) return;
        ic.beginBatchEdit();
        if (!currentPrefix.isEmpty()) ic.deleteSurroundingText(currentPrefix.length(), 0);
        ic.commitText(word + " ", 1);
        ic.endBatchEdit();
        engine.learn(word);
        lastSpace = SystemClock.uptimeMillis();
        updateAutoShift();
        updateSuggestions();
    }
}
