package com.arabickeyboard.pro;

public final class Theme {
    public static final String[] NAMES = {"فاتح", "داكن", "أزرق ليلي", "أخضر زمردي"};

    public final int bg, key, keyPressed, func, funcPressed, text, textFunc,
            accent, accentText, hint, shadow, popupBg, popupText;

    private Theme(int bg, int key, int keyPressed, int func, int funcPressed, int text,
                  int textFunc, int accent, int accentText, int hint, int shadow,
                  int popupBg, int popupText) {
        this.bg = bg;
        this.key = key;
        this.keyPressed = keyPressed;
        this.func = func;
        this.funcPressed = funcPressed;
        this.text = text;
        this.textFunc = textFunc;
        this.accent = accent;
        this.accentText = accentText;
        this.hint = hint;
        this.shadow = shadow;
        this.popupBg = popupBg;
        this.popupText = popupText;
    }

    public static Theme get(int id) {
        switch (id) {
            case 1:
                return new Theme(0xFF1E2126, 0xFF3A3F47, 0xFF565C67, 0xFF2C3036, 0xFF454A54,
                        0xFFF1F3F6, 0xFFD7DBE2, 0xFF4C8DF6, 0xFFFFFFFF, 0xFF9AA1AD,
                        0xFF121417, 0xFF4A505A, 0xFFFFFFFF);
            case 2:
                return new Theme(0xFF0F1A2E, 0xFF1D2D4A, 0xFF2F4670, 0xFF16233C, 0xFF2A3E64,
                        0xFFEAF0FF, 0xFFB9C7E6, 0xFFE0B04A, 0xFF1A1405, 0xFF7F92B8,
                        0xFF08101E, 0xFF2A3E64, 0xFFEAF0FF);
            case 3:
                return new Theme(0xFF0E2A24, 0xFF1C4A40, 0xFF2B6B5C, 0xFF143A32, 0xFF265E51,
                        0xFFEAFBF5, 0xFFB5DCCF, 0xFFF2C14E, 0xFF2A1F00, 0xFF7FB3A3,
                        0xFF081A16, 0xFF265E51, 0xFFEAFBF5);
            default:
                return new Theme(0xFFE9ECF1, 0xFFFFFFFF, 0xFFD5DAE3, 0xFFC9CFDA, 0xFFB4BBC9,
                        0xFF1B1F27, 0xFF2B303B, 0xFF1565C0, 0xFFFFFFFF, 0xFF7A8294,
                        0xFFB7BECB, 0xFFFFFFFF, 0xFF1B1F27);
        }
    }
}
