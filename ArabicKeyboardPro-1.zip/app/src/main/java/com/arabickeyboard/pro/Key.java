package com.arabickeyboard.pro;

import android.graphics.RectF;

public class Key {
    public static final int CHAR = 0;
    public static final int SHIFT = -1;
    public static final int SYM1 = -2;
    public static final int LANG = -3;
    public static final int ENTER = -4;
    public static final int DELETE = -5;
    public static final int EMOJI = -6;
    public static final int LETTERS = -7;
    public static final int SYM2 = -8;
    public static final int CAT = -9;
    public static final int SPACER = -10;
    public static final int SPACE = 32;

    public final int code;
    public final String label;
    public final String output;
    public final float weight;
    public String[] popups;
    public int arg;
    public boolean flat;
    public final RectF rect = new RectF();
    public boolean pressed;

    public Key(int code, String label, String output, float weight) {
        this.code = code;
        this.label = label;
        this.output = output;
        this.weight = weight;
    }

    public static Key ch(String s, String... pops) {
        Key k = new Key(CHAR, s, s, 1f);
        if (pops != null && pops.length > 0) k.popups = pops;
        return k;
    }

    public static Key mark(int cp) {
        String m = new String(Character.toChars(cp));
        return new Key(CHAR, "\u25CC" + m, m, 1f);
    }

    public static Key fn(int code, String label, float weight) {
        return new Key(code, label, "", weight);
    }

    public boolean isFunc() {
        return code != CHAR && code != SPACE;
    }
}
