package com.arabickeyboard.pro;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.view.MotionEvent;
import android.view.View;

import java.util.ArrayList;
import java.util.List;

public class SuggestionBar extends View {

    public interface Listener {
        void onSuggestion(String word);
    }

    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final float density;
    private final String[] slots = new String[3];
    private List<String> items = new ArrayList<>();
    private Theme theme = Theme.get(0);
    private Listener listener;
    private int downSlot = -1;

    public SuggestionBar(Context c) {
        super(c);
        density = c.getResources().getDisplayMetrics().density;
    }

    public void setListener(Listener l) { listener = l; }

    public void setTheme(Theme t) {
        theme = t;
        setBackgroundColor(t.bg);
        invalidate();
    }

    public void setSuggestions(List<String> list) {
        items = list == null ? new ArrayList<String>() : list;
        slots[0] = items.size() > 1 ? items.get(1) : null;
        slots[1] = items.size() > 0 ? items.get(0) : null;
        slots[2] = items.size() > 2 ? items.get(2) : null;
        invalidate();
    }

    @Override
    protected void onDraw(Canvas c) {
        int w = getWidth(), h = getHeight();
        float sw = w / 3f;
        paint.setTextAlign(Paint.Align.CENTER);
        paint.setTextSize(17 * density);
        Paint.FontMetrics fm = paint.getFontMetrics();
        float ty = h / 2f - (fm.ascent + fm.descent) / 2f;
        for (int i = 0; i < 3; i++) {
            if (slots[i] == null) continue;
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(i == 1 ? theme.text : theme.hint);
            paint.setTypeface(i == 1 ? Typeface.DEFAULT_BOLD : Typeface.DEFAULT);
            c.drawText(slots[i], sw * i + sw / 2f, ty, paint);
        }
        paint.setTypeface(Typeface.DEFAULT);
        paint.setColor(theme.hint);
        paint.setAlpha(70);
        for (int i = 1; i < 3; i++) {
            c.drawRect(sw * i - density / 2f, h * 0.25f, sw * i + density / 2f, h * 0.75f, paint);
        }
        paint.setAlpha(255);
    }

    private int slotAt(float x) {
        int s = (int) (x / (getWidth() / 3f));
        return Math.max(0, Math.min(2, s));
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                downSlot = slotAt(e.getX());
                return slots[downSlot] != null;
            case MotionEvent.ACTION_UP:
                int s = slotAt(e.getX());
                if (s == downSlot && slots[s] != null && listener != null) {
                    listener.onSuggestion(slots[s]);
                }
                downSlot = -1;
                return true;
            case MotionEvent.ACTION_CANCEL:
                downSlot = -1;
                return true;
            default:
                return true;
        }
    }
}
