package com.arabickeyboard.pro;

import android.content.Context;
import android.content.SharedPreferences;

public final class Prefs {
    public static final String THEME = "theme";
    public static final String VIBRATE = "vibrate";
    public static final String SOUND = "sound";
    public static final String PREVIEW = "preview";
    public static final String NUMBER_ROW = "number_row";
    public static final String SUGGEST = "suggest";
    public static final String DOUBLE_SPACE = "double_space";
    public static final String ARABIC_DIGITS = "arabic_digits";
    public static final String KEY_HEIGHT = "key_height";
    public static final String LAST_ARABIC = "last_arabic";

    private final SharedPreferences sp;

    public Prefs(Context c) {
        sp = c.getSharedPreferences("kb_prefs", Context.MODE_PRIVATE);
    }

    public boolean getBool(String key, boolean def) { return sp.getBoolean(key, def); }
    public void putBool(String key, boolean v) { sp.edit().putBoolean(key, v).apply(); }
    public int getInt(String key, int def) { return sp.getInt(key, def); }
    public void putInt(String key, int v) { sp.edit().putInt(key, v).apply(); }

    public int theme() { return getInt(THEME, 0); }
    public boolean vibrate() { return getBool(VIBRATE, true); }
    public boolean sound() { return getBool(SOUND, false); }
    public boolean preview() { return getBool(PREVIEW, true); }
    public boolean numberRow() { return getBool(NUMBER_ROW, true); }
    public boolean suggest() { return getBool(SUGGEST, true); }
    public boolean doubleSpace() { return getBool(DOUBLE_SPACE, true); }
    public boolean arabicDigits() { return getBool(ARABIC_DIGITS, false); }
    public int keyHeight() { return getInt(KEY_HEIGHT, 50); }
    public boolean lastArabic() { return getBool(LAST_ARABIC, true); }
    public void setLastArabic(boolean v) { putBool(LAST_ARABIC, v); }
}
